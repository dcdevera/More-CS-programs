
/**
 * Class for object Students
 *
 * @author Darren De Vera
 * @version 9/8/2019
 */
public class Students
{
    //Initialzation of name and student ID
    String name;
    int studentID;
    
    //Constructor
    public Students(String n, int id)
    {
        name = n;
        studentID = id;
    }
}
