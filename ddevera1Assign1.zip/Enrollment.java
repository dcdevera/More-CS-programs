
/**
 * Main file for ArrayList and Enhanced for each loop
 *
 * @author Darren De Vera
 * @version 9/8/2019
 */
import java.util.*;
public class Enrollment
{
   public static void main(System[]args)
   {
       //Creation of ArrayList and Students objects
       ArrayList<Students> classOne = new ArrayList<>();
       Students s1 = new Students("Kevin",1111);
       Students s2 = new Students("Jared",1122);
       Students s3 = new Students("Aleks",1333);
       Students s4 = new Students("Shia",1144);
       Students s5 = new Students("Orie",1115);
       //Placing objects into ArrayList
       classOne.add(s1);
       classOne.add(s2);
       classOne.add(s3);
       classOne.add(s4);
       classOne.add(s5);
       //Printing current ArrayList
       for(Students ss: classOne)
       {
           System.out.println("Name: " + ss.name + " Student ID: " + ss.studentID);
       }
       //Removing third in list
       classOne.remove(s3);
       //Printing new ArrayList
       System.out.println("");
       for(Students ss: classOne)
       {
           System.out.println("Name: " + ss.name + " Student ID: " + ss.studentID);
       }
       //Adding new Student into second position
       classOne.add(1, new Students("Billy", 2111));
       //Printing new ArrayList
       System.out.println("");
       for(Students ss: classOne)
       {
           System.out.println("Name: " + ss.name + " Student ID: " + ss.studentID);
       }
       //Printing size of ArrayList
       System.out.println("");
       System.out.println("Size of List: " + classOne.size());
       //Search for name and print result's student ID
       System.out.println("");
       for(Students ss: classOne)
       {
           
           if(ss.name == "Kevin")
           {
               System.out.println("Student ID: " + ss.studentID);
           }
           if(ss.name == "Jared")
           {
               System.out.println("Student ID: " + ss.studentID);
           }
           if(ss.name == "Aleks")
           {
               System.out.println("Student ID: " + ss.studentID);
           }
           if(ss.name == "Shia")
           {
               System.out.println("Student ID: " + ss.studentID);
           }
           if(ss.name == "Orie")
           {
               System.out.println("Student ID: " + ss.studentID);
           }
           if(ss.name == "Billy")
           {
               System.out.println("Student ID: " + ss.studentID);
           }
       }
   }   
}
