
/**
 * Write a description of class driver here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class driver
{
    public static void main(String[] args)
    {
       FindRoom fr = new FindRoom();
       fr.start();
       System.exit(0);
    }
}
